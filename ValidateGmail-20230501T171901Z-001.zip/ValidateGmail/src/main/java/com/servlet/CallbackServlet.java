package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeTokenRequest;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
import com.google.api.client.googleapis.auth.oauth2.GoogleTokenResponse;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;

/**
 * Servlet implementation class CallbackServlet
 */
@WebServlet("/callback")
public class CallbackServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String CLIENT_ID = "1051081727210-dk95elcco137d27mfjj0q56ck9d9ba6p.apps.googleusercontent.com";
    private static final String CLIENT_SECRET = "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";
    private static final String REDIRECT_URI = "http://localhost:8080/ValidateGmail/callback";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CallbackServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		System.out.println(request.getRequestURI());
		  String state = request.getParameter("state");
	        String code = request.getParameter("code");

	        if (state == null || !state.equals(request.getSession().getAttribute("state"))) {
	            response.sendRedirect("/");
	            System.out.println(request.getRequestURI());
	            System.out.println(request.getRequestURL());
	            return;
	        }

	        GoogleTokenResponse tokenResponse = new GoogleAuthorizationCodeTokenRequest(new NetHttpTransport(), JacksonFactory.getDefaultInstance(), "https://oauth2.googleapis.com/token", CLIENT_ID, CLIENT_SECRET, code, REDIRECT_URI).execute();

	        String accessToken = tokenResponse.getAccessToken();

	        GoogleIdToken idToken = tokenResponse.parseIdToken();

	        String email = idToken.getPayload().getEmail();
	        
	        System.out.println(accessToken+ " " +idToken+" "+email);

	        // TODO: do something with the user's email address

	        response.sendRedirect("success.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
