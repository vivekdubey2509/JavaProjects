package com.loginjdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



public class LoginCrudOps {
	public LoginBean bean (String name,String password)
	{
		
		Connect c= new Connect();
		Connection con=null;
		PreparedStatement ps= null;
		LoginBean bean= new LoginBean();
		
		con = c.getConnection();
		try {
			ps=con.prepareStatement("select * from registereduser where name=? and password=?");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			ps.setString(1,name);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			ps.setString(2,password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = ps.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		try {
			while(rs.next())
			{
				int id=rs.getInt("id");
//				String name=rs.getString("name");
				String age=rs.getString("age");
				String city=rs.getString("city");
				String state=rs.getString("state");
				String phonenumber=rs.getString("phonenumber");
				bean.setId(id);
				bean.setAge(age);
				bean.setCity(city);
				bean.setState(state);
				bean.setPhonenumber(phonenumber);
				
				System.out.println(bean.toString());
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bean;
		
	}


	

}
