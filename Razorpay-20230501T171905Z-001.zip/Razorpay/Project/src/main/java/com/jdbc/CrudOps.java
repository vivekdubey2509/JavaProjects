package com.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class CrudOps {
	
	
	
	
	
	

	public void insert(String name, String email, String contact, String amount, String rcpt)
	{
		Connect c= new Connect();
		Connection con=null;
		PreparedStatement ps=null;
		
		con=c.getConnection();
		try {
			ps=con.prepareStatement("insert into user (name,email,contact,amount,rcpt) values(?,?,?,?,?)");
			
			ps.setString(1, name);
			ps.setString(2, email);
			ps.setString(3, contact);
			ps.setString(4, amount);
			ps.setString(5, rcpt);
			ps.execute();
			
	
			System.out.println("inserted");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		public void update(String payid, String orderid, String signid,  String repstatus,String rcpt, String tdate)
		{
			Connect c= new Connect();
			Connection con=null;
			PreparedStatement ps=null;
			
			con=c.getConnection();
			try {
				ps=con.prepareStatement("update user set payid=?,orderid=?,signid=?,status=?,tdate=? where rcpt=? ");
				
				ps.setString(1, payid);
				ps.setString(2, orderid);
				ps.setString(3, signid);
				ps.setString(4, repstatus);
				ps.setString(5, tdate);
				ps.setString(6, rcpt);
				ps.execute();
				
		
				System.out.println("updated");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	
	
	
	

}}
