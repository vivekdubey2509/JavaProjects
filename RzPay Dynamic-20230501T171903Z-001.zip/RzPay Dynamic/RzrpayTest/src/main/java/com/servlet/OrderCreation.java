package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jdbc.CrudOps;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import com.razorpay.Utils;

import org.json.*;

/**
 * Servlet implementation class OrderCreation
 */
@WebServlet("/OrderCreation")
public class OrderCreation extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static String key = "rzp_test_avyp02yrZiVZXt";
	private static String secret = "Ru4NRo6dBAtZd5fUDcAnSJP7";
    
	//private static String key = "rzp_live_R1IVBWippGoR3Q";
	//private static String secret = "tLUG0m7SpDMoRwI1wYvRaaso";
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OrderCreation() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		System.out.println("order creation get method called");
		String name=request.getParameter("name");
		String email=request.getParameter("email");
		String contact=request.getParameter("contact");
		String amount=  Integer.parseInt(request.getParameter("amount"))*100 + "";
		String rcpt=request.getParameter("rcp");
		System.out.println("planid >> " + request.getParameter("planid"));
		
		System.out.println("before insert");
		CrudOps crudOps= new CrudOps();
		crudOps.insert(name, email, contact, amount,rcpt);
	
		RazorpayClient client=null;
		String orderId=null;
			
		try {
		

			RazorpayClient razorpay = new RazorpayClient(key, secret);

			JSONObject orderRequest = new JSONObject();
			orderRequest.put("amount",amount);
			orderRequest.put("currency","INR");
			orderRequest.put("receipt", "receipt#1dugd");
			JSONObject notes = new JSONObject();


			Order order = razorpay.Orders.create(orderRequest);
			orderId=order.get("id");
			
		}
		catch (RazorpayException e) {
			e.printStackTrace();
		}
		
		System.out.println("order id generated >> " + orderId);
		response.getWriter().append(orderId);
		
		
	}
		
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//doGet(request, response);
		System.out.println("order creation post method called");
		String payid=request.getParameter("payid");
		String orderid=request.getParameter("orderid");
		String signid=request.getParameter("signid");
		RazorpayClient client=null;
		try {
			client= new RazorpayClient(key, secret);
			//Utils.verifyWebhookSignature("<webhook_payload>", "<webhook_signature>", " <webhook_secret>");
			JSONObject options = new JSONObject();
			options.put("razorpay_order_id", orderid);
			options.put("razorpay_payment_id", payid);
			options.put("razorpay_signature", signid);
			boolean SigRes=Utils.verifyPaymentSignature(options,secret);
			if(SigRes) {
				System.out.println("Payment Failed & Signature Not Verified");
				response.getWriter().write("Payment Failed & Signature Not Verified");
			}
			else {
				System.out.println("Payment Successful & Signature  Verified");
				response.getWriter().write("Payment Successful & Signature  Verified");
			}			
		}
		catch (RazorpayException e) {
			e.printStackTrace();
		}
	}
}
