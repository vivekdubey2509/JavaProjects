package com.servlet;

import java.io.IOException;
import java.time.LocalDateTime;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jdbc.CrudOps;

/**
 * Servlet implementation class OrderUpdation
 */
@WebServlet("/OrderUpdation")
public class OrderUpdation extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OrderUpdation() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		String payid=request.getParameter("payid");
		String orderid=request.getParameter("orderid");
		String signid=request.getParameter("signid");
		String status=request.getParameter("status");
		String rcpt=request.getParameter("rcpt");
		String name=request.getParameter("name");
		String email=request.getParameter("email");
		String contact=request.getParameter("contact");
		String planid=request.getParameter("planid");
		
		System.out.println(name + ", " + email + ", " + contact + ", " + planid);
		LocalDateTime lt= LocalDateTime.now();
		System.out.println(lt.toString());
		String tdate=lt.toString();
		
		
		CrudOps crudOps= new CrudOps();
		crudOps.update(payid, orderid, signid, status, rcpt,tdate);
		
	}

}
