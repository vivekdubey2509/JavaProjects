package com.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Connect {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connect connect= new Connect();
		connect.getConnection();

	}
	
	
	public Connection getConnection()
	{
		Connection con=null;
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			String user="root";
			String password="root";
			String url="jdbc:mysql://localhost:3306/razorpay";
			con=DriverManager.getConnection(url, user, password);
		
			System.out.println("Connected Successfully");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return con;
		
		
		
		
		
		
		
	}


}
