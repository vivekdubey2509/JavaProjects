package com.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DetailsCrudOps {
	
	public DetailsBean bean(String email, String password)
	{
		Connect c = new Connect();
		Connection con = null;
		PreparedStatement ps = null;
		DetailsBean bean= new  DetailsBean();
		
		
		con = c.getConnection();
		try {
			ps = con.prepareStatement("select * from registereduser where email=? and password=?");
			ps.setString(1, email);
			ps.setString(2, password);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				int id = rs.getInt("id");
				String name = rs.getString("name");
				String age = rs.getString("age");
				String city= rs.getString("city");
				
				

				bean.setId(id);
				bean.setName(name);
				bean.setAge(age);
				bean.setCity(city);
				bean.setEmail(email);
				
				System.out.println(bean.toString());



}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bean;
	
	

}
}
