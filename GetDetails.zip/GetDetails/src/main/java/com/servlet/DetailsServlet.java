package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jdbc.Connect;
import com.jdbc.DetailsBean;
import com.jdbc.DetailsCrudOps;

/**
 * Servlet implementation class DetailsServlet
 */
@WebServlet("/DetailsServlet")
public class DetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DetailsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	    String email=request.getParameter("email");
	    String password=request.getParameter("password");
	    DetailsBean bean= new DetailsBean();
		DetailsCrudOps crudOps= new DetailsCrudOps();
		crudOps.bean(email, password);
		response.setContentType("text/html");
	    // Get a PrintWriter object to write HTML output
	    PrintWriter out = response.getWriter();
	
		// Step 1: Create login form
		// Assume you have created a JSP login page with a form that submits the username and password to a servlet
	

		// Step 2: Authenticate user
		// Assume you have a method called authenticateUser() that takes in the username and password and returns true if the credentials are valid
		if (bean.getId()>0) {
			response.getWriter().write("Invalid");
		    // Step 3: Retrieve user details from database
		}
			 else {
		    // Handle invalid login credentials
			
			try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		    String url = "jdbc:mysql://localhost:3306/shringaar";
		    String user = "root";
		    String dbPassword = "root";
		    try {
				Connection conn = DriverManager.getConnection(url, user, dbPassword);
				PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM registereduser WHERE email = ? and password=?");
				pstmt.setString(1, email);
				pstmt.setString(2, password);
				
				ResultSet rs = pstmt.executeQuery();
				if (rs.next()) {
				    String name = rs.getString("name");
				    String age = rs.getString("age");
				    String city = rs.getString("city");
				    // Step 4: Create HTML form

				    String html="<html>";
				    html += "<body  style='padding:100px 150px 140px 350px;'>";
				    html += "<div style='border:2px solid black;width:40%;height:200px;padding: 25px 40px 55px 100px;border-radius:20px;box-shadow:2px 3px 5px gray;'>";
				    
				    html += "<form method='get'>";
				    html += "Name: <input type='text' name='name' disabled='disabled'  value='" + name + "' style='color:red';><br>";
				    html += "Age: <input type='text' name='age' disabled='disabled' value='" + age + "'><br>";
				    html += "City: <input type='text' name='city' disabled='disabled' value='" + city + "'><br>";
				    html += "</form>";
				    html += "</div>";
				    html += "</body>";
				    html += "</html>";
				    
				    
				    
					response.getWriter().write(html);
				    // Write the HTML code to the response object
				    
				}
				rs.close();
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		}

		
	
	
	
	

	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
