package com.pixeltrice.springbootsendactivationlink;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootSendActivationLinkApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSendActivationLinkApplication.class, args);
	}

}
